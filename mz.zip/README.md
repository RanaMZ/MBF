# MBF
Multi Brute Force
<h1 align="center">
    💀MBF💀
</h1>
<h4 align="center">
  🇮🇩TRICKER RANA MZ🇮🇩
</h4>
<p align="center">
<a href="#"><img title="Author by Rana MZ" src="https://img.shields.io/badge/Coded%20By-Rana MZ-green?"></a>
<a href="#"><img title="Author by Rana MZ" src="https://img.shields.io/badge/Code%20-python2.7-blue?"></a>
<br>
<a href="https://github.com/Rana MZ/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Yayan-XD?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Rana MZ/termux-style/stargazers/">
  <a href="https://github.com/RanaMZ/MBF">
  </a>
  <a href="https://github.com/RanaMZ/MBF.git">
  </a>
  <a href="https://github.com/RanaMZ/MBF.git">
  </a>
  <a href="https://github.com/RanaMZ/MBF.git">
  </a>
  <a href="https://github.com/RanaMZ/MBF.git">
  </a>
  <a href="https://github.com/RanaMZ/MBF.git">
  </a>
  <a href="https://github.com/RanaMZ/MBF.git">
  </a>
</div>
<p align="center">

### Install
```
pkg update && pkg upgrade
pkg install git python2
pip2 install --upgrade pip
```
### And MBF this script
```
git clone https://github.com/RanaMZ/MBF.git
cd MBF
bash setup.sh
```

```
- Multi acc login
- Mutli type login
   - User pass
   - Token
```

## MY SOCIAL MEDIA
[![Github](https://img.shields.io/badge/Github-Ikuti-dark?style=for-the-badge&logo=github)](https://github.com/RanaMZ)
[![Facebook](https://img.shields.io/badge/Facebook-Ikuti-dark?style=for-the-badge&logo=facebook)](https://www.facebook.com/RanaMZ007/)
[![Instagram](https://img.shields.io/badge/Instagram-Ikuti-dark?style=for-the-badge&logo=instagram)](https://www.instagram.com/ranamz.zeshi)
